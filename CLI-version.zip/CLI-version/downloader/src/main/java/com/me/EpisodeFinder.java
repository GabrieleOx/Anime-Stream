package com.me;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.Dsl;

public class EpisodeFinder {

    public static ArrayList<String> getEpisodeList(char slash, int selectedUrl, String animeScelto, int indiceEpisodi, boolean itaAssoluto) throws IOException, ExecutionException, InterruptedException{
        int i = 1;
        ArrayList<String> episodes = new ArrayList<>();

        while(true){
            String name = nameComposer(i, animeScelto, indiceEpisodi, itaAssoluto);
            if(!isPresent(name))
                break;
            else {
                episodes.add(name);
            }
            i++;
            System.out.print("\rRicerca episodi in corso.  ");
            TimeUnit.MILLISECONDS.sleep(500);
            System.out.print("\rRicerca episodi in corso.. ");
            TimeUnit.MILLISECONDS.sleep(500);
            System.out.print("\rRicerca episodi in corso...");
            TimeUnit.MILLISECONDS.sleep(500);    
        }

        return episodes;
    }

    public static boolean isPresent(String url) throws IOException, InterruptedException, ExecutionException{
        boolean ret [] = new boolean[1];
        changeRet(ret, false);
        try (AsyncHttpClient client = Dsl.asyncHttpClient()) {

            client.prepareHead(url).execute().toCompletableFuture().thenAccept(response -> {
                int statusCode = response.getStatusCode();
                if (statusCode == 200) {
                    changeRet(ret, true);
                } else changeRet(ret, false);
            }).join();  // Aspetta che finisca la richiesta async
        }
        return ret[0];
    }

    private static void changeRet(boolean [] arr, boolean val){
        arr[0] = val;
    }

    private static String nameComposer(int epNumber, String baseUrl, int totEpisodi, boolean absITA){
        StringBuilder nEpisode = new StringBuilder();
        nEpisode.append("_Ep_");
        nEpisode.append(numeroEpisodio(epNumber, totEpisodi));

        String serie = getAnimeName(baseUrl), ep;
        boolean ita = serie.substring(serie.length() - 3, serie.length()).equals("ITA"), subIta = serie.substring(serie.length() - 6, serie.length()).equals("SUBITA");
        
        if(absITA){
            nEpisode.append("_ITA");
            ep = serie + nEpisode + ".mp4";
        }else if(ita && !subIta){
            nEpisode.append("_ITA");
            ep = serie.substring(0, serie.length() - 3) + nEpisode + ".mp4";
        }else if(subIta){
            nEpisode.append("_SUB_ITA");
            ep = serie.substring(0, serie.length()-6) + nEpisode + ".mp4";
        }else {
            nEpisode.append("_SUB_ITA");
            ep = serie + nEpisode + ".mp4";
        }

        return baseUrl + ep;
    }

    private static String numeroEpisodio(int n, int nEpisodes){
        int nZeroes = 0, nCiphers = 0, nCopy = n;
        while(nEpisodes > 9){
            nZeroes++;
            nEpisodes /= 10;
        }
        while(nCopy > 9){
            nCiphers++;
            nCopy /= 10;
        }
        StringBuilder num = new StringBuilder();
        for(int i = 0; i < (nZeroes - nCiphers); i++)
            num.append(0);
        num.append(n);
        return num.toString();
    }

    public static String getAnimeName(String url){
        int slash = 0, urlLen = url.length(), j = urlLen;
        while(slash < 2){
            j--;
            if(url.charAt(j) == '/')
                slash++;
        }
        return url.substring(j+1, urlLen-1);
    }
}

